package com.lti.vehicle.DAOImpl;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.transaction.annotation.Transactional;

import com.lti.vehicle.dao.ClaimDao;
import com.lti.vehicle.model.Claim;

	@Transactional
	public class ClaimDaoImpl implements ClaimDao{

		private static final Logger logger = 			
				LoggerFactory.getLogger(VehicleDaoImpl.class);

		private SessionFactory sessionFactory;


		@Autowired
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}


		@Override
		public void addClaimDetails(Claim c) {
			// TODO Auto-generated method stub
			Session session = this.sessionFactory.openSession();
			Transaction tx= session.beginTransaction();
			session.save(c);
			logger.info("Claim details saved successfully, Claim Details="+ c);
			tx.commit();
		}
			
		}
		
