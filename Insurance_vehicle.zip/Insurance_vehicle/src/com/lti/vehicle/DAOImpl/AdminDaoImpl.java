package com.lti.vehicle.DAOImpl;

	import java.util.List;

	import javax.transaction.Transactional;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;


	import com.lti.vehicle.dao.IAdminDao;
	import com.lti.vehicle.model.Claim;
	import com.lti.vehicle.model.UserDetails;

	@Transactional
	@Repository
	public class AdminDaoImpl implements IAdminDao {

		@Autowired
		private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Override
		public List<Claim> claimlist() {
			// TODO Auto-generated method stub
			Session session = this.sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			String query="from Claim";
			Query q=session.createQuery(query);
			List<Claim> claimlist=q.list();
			System.out.println(claimlist);
			tx.commit();
			session.close();
			return claimlist;

		}

		@Override
		public void acceptClaim(int claimId) {
			// TODO Auto-generated method stub
			Session session = this.sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			System.out.println("above query");
			System.out.println("this is"+claimId);
			
			
		
			String query="update Claim c set c.claimStatus='ACCEPTED' where c.claimId=:claimId";
			Query q=session.createQuery(query);
			q.setInteger("claimId", claimId);
			q.executeUpdate();
			System.out.println("exeupdate"+q.executeUpdate());
			tx.commit();

			
			
		}

		@Override
		public void rejectUser(int claimId) {
			// TODO Auto-generated method stub
			Session session = this.sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			String query="update Claim c set c.claimStatus='REJECTED' where c.claimId=:claimId";
			Query q=session.createQuery(query);
			q.setInteger("claimId", claimId);
			q.executeUpdate();
			tx.commit();
			

		}

		@Override
		public List<Claim> fetchClaimDetails(int claimId) {
			// TODO Auto-generated method stub
			Session session = this.sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			String query="from Claim c where c.claimId=:claimId";
			Query q=session.createQuery(query);
			q.setInteger("claimId", claimId);
			List<Claim> claimlist=q.list();
			System.out.println("clist"+claimlist);
			tx.commit();
			session.close();
			return claimlist;

		}


	}

