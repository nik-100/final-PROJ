package com.lti.vehicle.service;


import org.springframework.beans.factory.annotation.Autowired;

import com.lti.vehicle.dao.PaymentDao;
import com.lti.vehicle.model.Payment;

	public class PaymentServiceImpl implements PaymentServiceDao{

		@Autowired
		private PaymentDao paymentDao;
		
		public PaymentDao getPaymentDao() {
			return paymentDao;
		}

		public void setPaymentDao(PaymentDao paymentDao) {
			this.paymentDao = paymentDao;
		}

		@Override
		public void addPayment(Payment p) {
			// TODO Auto-generated method stub
			this.paymentDao.addPayment(p);
			
		}

}
