package com.lti.vehicle.service;

import com.lti.vehicle.model.Plans;

public interface IPlanService {
	
	 public void addPlan (Plans p);
}
