package com.lti.vehicle.service;

import com.lti.vehicle.model.Claim;

public interface IClaimService {
	
	 public void addClaimDetails(Claim c);

}

