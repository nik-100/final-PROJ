package com.lti.vehicle.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lti.vehicle.dao.ClaimDao;
import com.lti.vehicle.model.Claim;

public class ClaimServiceImpl implements IClaimService {

	@Autowired
	private ClaimDao claimDao;
	
	public ClaimDao getClaimDao() {
		return claimDao;
	}


	public void setClaimDao(ClaimDao claimDao) {
		this.claimDao = claimDao;
	}



	@Override
	public void addClaimDetails(Claim c) {
		// TODO Auto-generated method stub
		this.claimDao.addClaimDetails(c);
	}





}
