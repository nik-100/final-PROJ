package com.lti.vehicle.controller;

import java.util.Arrays;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.vehicle.model.ApplicationInsurance;
import com.lti.vehicle.model.Claim;
import com.lti.vehicle.model.Payment;
import com.lti.vehicle.model.Plans;
import com.lti.vehicle.model.UserDetails;
import com.lti.vehicle.model.VehicleDetails;
import com.lti.vehicle.service.IApplicationInsuranceService;
import com.lti.vehicle.service.IClaimService;
import com.lti.vehicle.service.IPlanService;
import com.lti.vehicle.service.IVehicleService;
import com.lti.vehicle.service.PaymentServiceDao;


@Controller
@SessionAttributes({"vehicle","plan","applicationInsurance","premium","claim"})
public class VehicleController {
	
private IVehicleService iVehicleService;
private IPlanService iPlanService;
private IApplicationInsuranceService iApplicationInsuranceService;
private PaymentServiceDao paymentServiceDao;
private IClaimService iClaimService;


/*private IBasicCalculatorService iBasicCalculatorService;



@Autowired
public void setiBasicCalculatorService(IBasicCalculatorService bs) {
	this.iBasicCalculatorService = bs;
}*/


@Autowired
	public void setiClaimService(IClaimService cs) {
	this.iClaimService = cs;
}


@Autowired
public void setPaymentServiceDao(PaymentServiceDao pd) {
	this.paymentServiceDao = pd;
}

@Autowired
public void setiApplicationInsuranceService(IApplicationInsuranceService as) {
	this.iApplicationInsuranceService = as;
}

@Autowired
	public void setiPlanService(IPlanService ps) {
	this.iPlanService = ps;
}



	@Autowired
	public void setiVehicleService(IVehicleService vs) {
		this.iVehicleService = vs;
	}


	@ModelAttribute
	public void getVehicleType(Model model)
	{
	model.addAttribute("vehicletype",Arrays.asList("4w","2w"));
	}
	
	
@ModelAttribute
public void getBrand(Model model)
{
model.addAttribute("fwbrands",Arrays.asList("Suzuki","Renault","Apache","Pulsar"));

}
@ModelAttribute
public void getModel(Model model)
{
model.addAttribute("Model",Arrays.asList("Baleno","Swift","Alto","kwid","scala","ApacheRTR","Pulsar220"));

}

@ModelAttribute
public void getPurchaseMonth(Model model)
{
model.addAttribute("pmonth",Arrays.asList("1","2","3","4","5","6","7","8","9","10","11","12"));
}
@ModelAttribute
public void getPurchaseYear(Model model)
{
model.addAttribute("pyear",Arrays.asList("2009","2010","2011","2012","2013","2014","2015","2016","2017","2018"));
}


@ModelAttribute
public void getPlanType(Model model)
{
model.addAttribute("plantypes",Arrays.asList("Comprehensive","3rdParty"));
model.addAttribute("planyears",Arrays.asList("1","2","3"));
}

///////////////////////Initial step adding vehicle details
	@RequestMapping(value="/vehicles")
	public String listVehicleDetails(Model model, HttpSession session) {
		
		model.addAttribute("vehicle", new VehicleDetails());
		

		
		return "vehicle";
	}
	
///////////////////////Adding plans
	@RequestMapping(value="/vehicles/plans")
	public String addplans(Model model,@ModelAttribute("vehicle")  VehicleDetails v,HttpSession session) {
			model.addAttribute("plan", new Plans());
		return "plans";
	}
	
	
	@RequestMapping(value="/vehicles/receipt")
	public String addPayment(Model model) {

		model.addAttribute("receipt", new Payment());
		return "receipt";
	}
	
	
	
	
	@RequestMapping(value="/vehicles/calculate")
	public String calculatePremium(Model model) {

		model.addAttribute("premium", new Plans());
		return "totalpremium";
	}
	
	
	@RequestMapping(value = "/vehicles/add",method = RequestMethod.POST)
/*	@ExceptionHandler({ CustomException.class })*/
	public String addVehicle(
			@ModelAttribute("vehicle") 
			@Valid VehicleDetails v, 
			BindingResult result, 
			Model model,HttpSession session) {
	
		UserDetails ud = (UserDetails)session.getAttribute("uDetails");
		v.setUserDetails(ud);
     
           ud.setVehicleDetails(v);
           this.iVehicleService.addVehicle(v);	
			session.setAttribute("vehicle",v);
		return "vehsuccess";
	}
	
	
	
	
	
	@RequestMapping(value = "/vehicles/plans/adds",method = RequestMethod.POST)
/*	@ExceptionHandler({ CustomException.class })*/
	public String addPlan(
			@ModelAttribute("plan") 
			@Valid Plans p,
			BindingResult result, 
			Model model, HttpSession session) {
		if(!result.hasErrors())
		{
			
			
			
		/*	UserDetails ud = (UserDetails)session.getAttribute("uDetails");
			v.setUserDetails(ud);
	     
	           ud.setVehicleDetails(v);
	           this.iVehicleService.addVehicle(v);	
				session.setAttribute("vehicle",v);*/
			
			
		
			/*VehicleDetails vd=(VehicleDetails)session.getAttribute("vehicle");
			vd.setPlans(p);
			
			p.setVehicleDetails(vd);*/

			
			this.iPlanService.addPlan(p);
			session.setAttribute("plan", p);
			
			
				}
		return "calcpremium";
	}
	
	
@RequestMapping("/vehicles/plans/calculate")
	public String calc(Model model,HttpSession session)
	{
	 VehicleDetails v1 = (VehicleDetails)session.getAttribute("vehicle");
	Plans p1  =(Plans)session.getAttribute("plan");
	ApplicationInsurance  appIns =  new ApplicationInsurance();
	appIns.setApplicationId(121212);
	appIns.setTempVehicle(v1);
	appIns.setTempPlan(p1);
	session.setAttribute("applicationInsurance",appIns);
	
   double premium =iApplicationInsuranceService.calculatePremium(appIns);
   model.addAttribute("premium",premium);
   session.setAttribute("premium",premium);
	return "totalpremium";
	}


@RequestMapping(value = "/vehicles/plans/calculate/receipt",method = RequestMethod.POST)
/*	@ExceptionHandler({ CustomException.class })*/
	public String addPayment(
			@ModelAttribute("receipt") 
			@Valid Payment r, 
			BindingResult result, 
			Model model, HttpSession session) {
		if(!result.hasErrors())
		{	
		double payAmount= (double) session.getAttribute("premium");
			r.setPayAmount(payAmount);
		System.out.println(r);
			this.paymentServiceDao.addPayment(r);
		}
		
		return "receipt";
	}


/////////////////////////////////redirect to claim home

@RequestMapping(value = "/vehicles/plans/calculate/claimhome")
/*	@ExceptionHandler({ CustomException.class })*/
	public String redirectClaimHome(Model model,HttpSession ses)
	{
	ApplicationInsurance inspolicy =(ApplicationInsurance)ses.getAttribute("applicationInsurance");
	model.addAttribute("policy",inspolicy);
		return "claimhome";
	}


////////////////////////////////Adding Claim Details
@RequestMapping(value="/vehicles/plans/calculate/claims")
public String claimDetails(Model model) {

	model.addAttribute("claim", new Claim());
	return "claim";
}
	


@RequestMapping(value = "/vehicles/plans/calculate/submit",method = RequestMethod.POST)
public String addVehicle(
		@ModelAttribute("claim") 
		@Valid Claim c, 
		BindingResult result, 
		Model model,HttpSession session) {
	
	if(!result.hasErrors())
	{
		Plans ps=(Plans)session.getAttribute("plan");
		//////////////////////
		this.iClaimService.addClaimDetails(c);

	}
	return "claimsent";
}






/*
@RequestMapping("/claims/sclaim")
public ApplicationInsurance dispClaim(Model model,HttpSession session)
{
Plans p1  =(Plans)session.getAttribute("plan");
Payment py  =(Payment)session.getAttribute("plan");
ApplicationInsurance  appIns =  new ApplicationInsurance();
appIns.setApplicationId(12112);
appIns.setTempPlan(p1);
appIns.setTempPayment(py);
session.setAttribute("applicationInsurance",appIns);

double claimDisp = iApplicationInsuranceService.displayClaimDetails(appIns);
model.addAttribute("tempPay",claimDisp);
session.setAttribute("tempPay",claimDisp);
return claimsent;
}
*/

/*
//////////////////////////////////////////////Addinf Details to basic Calculator model
@RequestMapping(value="/calbasic")
public String basicCalculator(Model model) {

	model.addAttribute("basic", new BasicCalculator());
	
	return "basiccalculator";
}*/




}
	
