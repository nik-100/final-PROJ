package com.lti.vehicle.dao;

import com.lti.vehicle.model.Payment;

public interface PaymentDao {
		 public void addPayment (Payment p);

	}


